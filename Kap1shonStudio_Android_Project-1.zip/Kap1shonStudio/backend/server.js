import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

const app = express();
app.use(helmet());
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 20 }));
const PORT = process.env.PORT || 8080;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

app.get("/health", (_req, res) => res.json({ ok: true, service: "Kap1shon Studio API" }));

app.post("/api/generate", async (req, res) => {
  if (!OPENAI_API_KEY) return res.status(503).json({ error: "На сервере не задан OPENAI_API_KEY." });
  const { prompt, existingCode = "", model = "gpt-4.1-mini" } = req.body || {};
  if (typeof prompt !== "string" || !prompt.trim()) return res.status(400).json({ error: "Нужно описание проекта." });
  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        instructions: "Ты опытный Android-разработчик. Генерируй полные исходники по задаче. Не заявляй, что APK собран. Если меняешь код — верни полную обновлённую версию.",
        input: `ЗАДАЧА:\n${prompt}\n\nТЕКУЩИЙ КОД:\n${existingCode}`,
        max_output_tokens: 12000
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || "Ошибка OpenAI API" });
    res.json({ output: data.output_text || "", response_id: data.id });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, () => console.log(`Kap1shon API listening on ${PORT}`));
