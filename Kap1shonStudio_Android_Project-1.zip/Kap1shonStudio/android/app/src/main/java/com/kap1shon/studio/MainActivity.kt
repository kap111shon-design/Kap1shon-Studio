package com.kap1shon.studio

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

private val Purple = Color(0xFF8B5CF6)
private val Dark = Color(0xFF11111A)
private val Panel = Color(0xFF1D1B2A)
private val Muted = Color(0xFFAAA5BB)

data class StudioProject(
    val id: String,
    val name: String,
    val prompt: String,
    val code: String,
    val updated: Long,
    val history: List<String> = emptyList()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Kap1shonApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Kap1shonApp(context: Context) {
    val scope = rememberCoroutineScope()
    val prefs = remember { SecurePrefs(context) }
    var apiKey by remember { mutableStateOf(prefs.get("api_key")) }
    var apiUrl by remember { mutableStateOf(prefs.get("api_url").ifBlank { "https://api.openai.com/v1/responses" }) }
    var model by remember { mutableStateOf(prefs.get("model").ifBlank { "gpt-4.1-mini" }) }
    var showSettings by remember { mutableStateOf(false) }
    var prompt by remember { mutableStateOf("") }
    var projectName by remember { mutableStateOf("") }
    var projects by remember { mutableStateOf(loadProjects(context)) }
    var selected by remember { mutableStateOf<StudioProject?>(null) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Готов к созданию") }
    var error by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var showCode by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && selected != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(selected!!.code)
                }
            }.onSuccess { status = "Исходный код экспортирован" }
             .onFailure { error = "Не удалось сохранить файл: ${it.message}" }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, background = Dark, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Dark,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Kap1shon Studio", fontWeight = FontWeight.Bold)
                            Text("Твоя студия приложений с ИИ", fontSize = 11.sp, color = Muted)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, "Настройки", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Dark)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.AutoAwesome, null) }, label = { Text("Создать") }
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Folder, null) }, label = { Text("Проекты") }
                    )
                }
            }
        ) { padding ->
            if (tab == 0) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(22.dp)
                        ) {
                            Column(Modifier.padding(18.dp)) {
                                Text("Создай приложение мечты", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(6.dp))
                                Text("Опиши идею обычными словами. ИИ подготовит исходный код и поможет его доработать.", color = Muted)
                                Spacer(Modifier.height(14.dp))
                                OutlinedTextField(
                                    value = projectName, onValueChange = { projectName = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Название проекта") },
                                    placeholder = { Text("Например, Моя игра") },
                                    singleLine = true
                                )
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = prompt, onValueChange = { prompt = it },
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
                                    label = { Text("Опиши приложение") },
                                    placeholder = { Text("Создай игру Gravity Defied с мотоциклом, уровнями, кнопками управления и красивой графикой...") }
                                )
                                Spacer(Modifier.height(14.dp))
                                Button(
                                    onClick = {
                                        if (apiKey.isBlank()) {
                                            error = "Сначала добавь API-ключ в настройках ИИ."
                                            showSettings = true
                                        } else if (prompt.isBlank()) {
                                            error = "Напиши описание приложения."
                                        } else {
                                            busy = true; error = ""; status = "ИИ создаёт проект…"
                                            scope.launch {
                                                try {
                                                    val code = OpenAiClient.generate(apiUrl, apiKey, model, prompt, null)
                                                    val p = StudioProject(
                                                        UUID.randomUUID().toString(),
                                                        projectName.ifBlank { "Новый проект" },
                                                        prompt, code, System.currentTimeMillis()
                                                    )
                                                    projects = listOf(p) + projects
                                                    saveProjects(context, projects)
                                                    selected = p
                                                    status = "Проект создан. Можно дорабатывать код."
                                                    tab = 1
                                                } catch (e: Exception) {
                                                    error = e.message ?: "Неизвестная ошибка"
                                                    status = "Не удалось создать проект"
                                                } finally { busy = false }
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(52.dp),
                                    enabled = !busy,
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                    else Icon(Icons.Default.AutoAwesome, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (busy) "Создаём…" else "Создать с ИИ")
                                }
                            }
                        }
                    }
                    item { StatusLine(status) }
                    if (error.isNotBlank()) item { Text(error, color = Color(0xFFFF8A8A)) }
                    item {
                        InfoCard(
                            "Как это работает",
                            "1. Опиши идею\n2. ИИ сгенерирует исходный код\n3. Открой проект и попроси внести изменения\n4. Экспортируй код для сборки APK"
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text("Мои проекты", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("${projects.size} сохранено на устройстве", color = Muted)
                    }
                    if (projects.isEmpty()) item { InfoCard("Пока пусто", "Создай первый проект на вкладке «Создать».") }
                    items(projects, key = { it.id }) { p ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { selected = p; showCode = false },
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Android, null, tint = Purple, modifier = Modifier.size(32.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.SemiBold)
                                    Text(p.prompt.take(70), color = Muted, fontSize = 12.sp, maxLines = 2)
                                }
                                IconButton(onClick = {
                                    projects = projects.filterNot { it.id == p.id }
                                    saveProjects(context, projects)
                                    if (selected?.id == p.id) selected = null
                                }) { Icon(Icons.Default.DeleteOutline, "Удалить", tint = Muted) }
                            }
                        }
                    }
                    selected?.let { p ->
                        item {
                            Divider(color = Muted.copy(alpha = .25f))
                            Text(p.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Редактирование проекта", color = Muted)
                            var changeRequest by remember(p.id) { mutableStateOf("") }
                            OutlinedTextField(
                                value = changeRequest, onValueChange = { changeRequest = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Что изменить?") },
                                placeholder = { Text("Добавь меню, уровни, настройки…") }
                            )
                            Button(
                                onClick = {
                                    if (changeRequest.isBlank()) return@Button
                                    busy = true; error = ""
                                    scope.launch {
                                        try {
                                            val revised = OpenAiClient.generate(
                                                apiUrl, apiKey, model, changeRequest, p.code
                                            )
                                            val updated = p.copy(
                                                code = revised,
                                                updated = System.currentTimeMillis(),
                                                history = p.history + p.code
                                            )
                                            projects = projects.map { if (it.id == p.id) updated else it }
                                            saveProjects(context, projects)
                                            selected = updated
                                            status = "Изменения сохранены"
                                        } catch (e: Exception) {
                                            error = e.message ?: "Ошибка ИИ"
                                        } finally { busy = false }
                                    }
                                },
                                enabled = !busy && apiKey.isNotBlank(),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (busy) "ИИ работает…" else "Применить изменения") }
                            OutlinedButton(
                                onClick = { showCode = !showCode },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (showCode) "Скрыть код" else "Просмотреть исходный код") }
                            if (showCode) {
                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF090910))) {
                                    Text(
                                        p.code,
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        fontSize = 11.sp,
                                        color = Color(0xFFD8D2E8)
                                    )
                                }
                            }
                            Button(
                                onClick = { exportLauncher.launch("${p.name.replace(" ", "_")}.txt") },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp))
                                Text("Экспортировать исходный код")
                            }
                            OutlinedButton(
                                onClick = {
                                    status = "Для APK нужна сборка Android-проекта в Android Studio или CI. Экспортируй исходники и собери проект там."
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Icon(Icons.Default.Build, null); Spacer(Modifier.width(8.dp)); Text("Подготовка к сборке APK") }
                            Text(status, color = Muted, fontSize = 12.sp)
                            if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A8A))
                        }
                    }
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Настройки ИИ") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("API-ключ хранится на устройстве в зашифрованном хранилище.", fontSize = 12.sp, color = Muted)
                    OutlinedTextField(
                        value = apiKey, onValueChange = { apiKey = it },
                        label = { Text("OpenAI API key") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true
                    )
                    OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Модель") }, singleLine = true)
                    OutlinedTextField(value = apiUrl, onValueChange = { apiUrl = it }, label = { Text("Адрес API") }, singleLine = true)
                    Text("По умолчанию используется OpenAI Responses API.", fontSize = 11.sp, color = Muted)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    prefs.put("api_key", apiKey.trim())
                    prefs.put("model", model.trim())
                    prefs.put("api_url", apiUrl.trim())
                    showSettings = false
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Отмена") } }
        )
    }
}

@Composable
fun StatusLine(value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Circle, null, tint = Purple, modifier = Modifier.size(9.dp))
        Spacer(Modifier.width(8.dp))
        Text(value, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(body, color = Muted, fontSize = 13.sp)
        }
    }
}

private class SecurePrefs(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "kap1shon_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun get(key: String) = prefs.getString(key, "") ?: ""
    fun put(key: String, value: String) { prefs.edit().putString(key, value).apply() }
}

private object OpenAiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generate(url: String, key: String, model: String, prompt: String, existing: String?): String =
        withContext(Dispatchers.IO) {
            val instruction = """
                Ты — опытный Android-разработчик и архитектор приложений.
                Подготовь качественный исходный код и техническое описание проекта по запросу пользователя.
                Если дан существующий код, внеси запрошенные изменения, сохранив полезную функциональность.
                Верни результат в формате:
                # Описание
                Кратко опиши структуру и функции.
                # Исходный код
                ```kotlin
                // Полный Kotlin-код основного экрана/логики, без пропусков
                ```
                # Сборка
                Укажи необходимые зависимости и шаги сборки.
                Не утверждай, что APK уже собран. Если запрос требует нескольких файлов, перечисли каждый файл с путём и полным содержимым.
            """.trimIndent()
            val userText = buildString {
                append("ЗАДАЧА:\n").append(prompt)
                if (!existing.isNullOrBlank()) {
                    append("\n\nТЕКУЩИЙ ПРОЕКТ:\n").append(existing)
                    append("\n\nВерни обновлённую полную версию, а не только список советов.")
                }
            }
            val body = JSONObject()
                .put("model", model)
                .put("instructions", instruction)
                .put("input", userText)
                .put("max_output_tokens", 12000)
                .toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $key")
                .header("Content-Type", "application/json")
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val message = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                    throw IOException("OpenAI API (${response.code}): ${message ?: raw.take(500)}")
                }
                val json = JSONObject(raw)
                val direct = json.optString("output_text")
                if (direct.isNotBlank()) return@withContext direct
                val output = json.optJSONArray("output") ?: JSONArray()
                val result = StringBuilder()
                for (i in 0 until output.length()) {
                    val content = output.optJSONObject(i)?.optJSONArray("content") ?: continue
                    for (j in 0 until content.length()) {
                        val item = content.optJSONObject(j) ?: continue
                        if (item.optString("type") == "output_text") result.append(item.optString("text"))
                    }
                }
                result.toString().ifBlank { throw IOException("ИИ вернул пустой ответ.") }
            }
        }
}

private fun loadProjects(context: Context): List<StudioProject> {
    return runCatching {
        val raw = context.getSharedPreferences("projects", Context.MODE_PRIVATE).getString("data", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val hist = o.optJSONArray("history") ?: JSONArray()
            StudioProject(
                o.getString("id"), o.getString("name"), o.getString("prompt"),
                o.getString("code"), o.getLong("updated"),
                (0 until hist.length()).map { hist.getString(it) }
            )
        }
    }.getOrDefault(emptyList())
}

private fun saveProjects(context: Context, projects: List<StudioProject>) {
    val arr = JSONArray()
    projects.forEach { p ->
        arr.put(JSONObject()
            .put("id", p.id).put("name", p.name).put("prompt", p.prompt)
            .put("code", p.code).put("updated", p.updated)
            .put("history", JSONArray(p.history)))
    }
    context.getSharedPreferences("projects", Context.MODE_PRIVATE)
        .edit().putString("data", arr.toString()).apply()
}
